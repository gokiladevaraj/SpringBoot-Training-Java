package RibbonLoadBalancer.RibbonLoadBalancer;
import java.net.URI;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/loadBalance")
public class RibbonController {
     //LoadBalancerClient is a built in class
	//This class contains the methods  or logic for load balancing.
	@Autowired
	private LoadBalancerClient  balance;
	
	//RestTemplat is built in class. This is the router and it contain  built in router logic.
	private RestTemplate resttemp=new RestTemplate();
	
	/*Load balancing logic*/
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public ArrayList<Product> getProductList()
	{
		//Choose() method chooses one instance/service among the 3 instances 
		//mentioned in properties file.
		//Choose () method selects the instance.
		//Generally this follows Round-robin mechanism by default.
		//This invokes the load balancer. Loadbalancer chooses the appropriate backend service
		
		//ServiceInstance represents the backend service choosen by the load balancer.
		//load balance name is balanceload. The loadbalancer is intialized.
		//load balance choose one of the copies in the list.
		//instance represents that copy.
		ServiceInstance instance=balance.choose("balanceload");
		//prints the details about the copy that is selected
		//Prepare the URI with the endpoint for that instance
		//This forms a URL for : http://localhost:9060/
		URI  products = URI.create(String.format("http://%s:%s", instance.getHost(), instance.getPort()));
		//For ex: if it has selected  localhost:9003, the uri will be : -
			//	http://localhost:9003/
		
		//Finds out which instance it is calling.
		
		System.out.println("routing to - " + products.getHost() + " : " + products.getPort());
		//Calling the instance choosen.
		String result="<B>Data returned by </b>" + products.getHost() + " : " + 
		products.getPort() + "<BR>"; 
		//Routing to the actual api  implement in the copies
		//path to the actual API is prepared
		String url=products.toString() + "/shopping/list";
		/*If it has selected localhost:9003, then the url will be
		 * http://localhost:9082/pizzas/info
		 */
		ArrayList<Product> al=null;
		try {
			//Actual routing happen here. Invoke a API here
			//If the load balancer has seleceted localhost:9082, then
			//the full url will be http://localhost:9082/shopping/list
			//Invoke the /list api in the copy that is running at 9082.
		al= resttemp.getForObject( url, ArrayList.class);
		} catch(Exception e) {
			System.out.println
			("Unable to contact service @ " + products);
			//getAllProducts();
		}
		
		return al;
		
	}
}
